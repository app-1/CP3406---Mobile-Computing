package au.edu.jcu.cp3406.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class QuizComplete extends AppCompatActivity {

    private EditText userNameInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_complete);

        userNameInput = findViewById(R.id.nameUserInput);

    }

    public void saveButton(View view) {
//        checkUserNameInput();
//        toHighScores();
        Toast.makeText(this, "Name and score have successfully been added", Toast.LENGTH_SHORT).show();
    }

    public void cancelButton(View view) {
        toHighScores();
    }

    private void toHighScores() {
        finish();
    }

    //Check if username input is empty
    private void checkUserNameInput(){
        if(userNameInput.getText().toString().matches("")){
            Toast.makeText(this, "Please enter name", Toast.LENGTH_SHORT).show();
        }
    }

}
