package au.edu.jcu.cp3406.assignment2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements SensorEventListener {


    //Declare variables for Sensor Event handling
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float deltaX = 0;
    private float deltaY = 0;
    private float deltaZ = 0;
    private float lastX, lastY, lastZ;
    private float vibrateThreshold = 0;


    private static final int REQUEST_CODE_QUIZ = 1;
    public static final String EXTRA_DIFFICULTY = "extraDifficulty";
    public static final String EXTRA_CATEGORY_ID = "extraCategoryID";
    public static final String EXTRA_CATEGORY_NAME = "extraCategoryName";

    public static final String SHARED_PREFS = "sharedPrefences";
    public static final String KEY_HIGHSCORE = "keyHighScore";

    private TextView textViewHighScore;
    private Spinner spinnerDifficulty;
    private Spinner spinnerCategory;

    private int highscore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Sensor Manager ID's

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        startShakeListener();


        textViewHighScore = findViewById(R.id.highScoreView);
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty);
        spinnerCategory = findViewById(R.id.spinnerCategory);

//        String[] difficultyLevels = Question.getAllDifficultyLevels();
//
//        //Fill spinner with pre-defined difficulty levels
//        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<String>(this,
//                android.R.layout.simple_spinner_item, difficultyLevels);
//        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinnerDifficulty.setAdapter(adapterDifficulty);

        loadCategories();
        loadDifficultyLevelsWithHint();
        loadHighScore();

//        spinnerHint();
//        loadDifficultyLevels();


    }

    //SpinnerHint
//    private void spinnerHint() {
//
//        ArrayList<String> myList;
//        myList = new ArrayList<String>();
//
//        final String hint = "Select category...";
//        String levels = Arrays.toString(Question.getAllDifficultyLevels());
//        myList.add(hint);
//        myList.add(levels);
//
//        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, myList) {
//
//            @Override
//            public boolean isEnabled(int position) {
//                if (position == 0) {
//                    return false;
//                } else {
//                    return true;
//                }
//            }
//
//            @Override
//            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
//                View view =  super.getDropDownView(position, convertView, parent);
//
//                TextView tv = (TextView) view;
//                if(position == 0){
//                    //Set hint text colour gray
//                    tv.setTextColor(Color.GRAY);
//                }else{
//                    tv.setTextColor(Color.BLACK);
//                }return view;
//            }
//
//
//        };
//        adapterDifficulty.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
//        spinnerDifficulty.setAdapter(adapterDifficulty);
//        spinnerDifficulty.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedItem = (String) parent.getItemAtPosition(position);
//
//                if(position > 0){
//                    //Notify selected item text
//                    Toast.makeText(MainActivity.this, "Selected : " + selectedItem, Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
//
//
//    }


    private void initializeQuiz() {
        //Cast string to type category
//        Category selectCategory = (Category) spinnerCategory.getSelectedItem();


        //Create new category object
        Category selectCategory = new Category();
//        Category selectCategory = (Category) spinnerCategory.getSelectedItem();

        if (spinnerCategory.getSelectedItem().equals("Programming")) {
            selectCategory.setId(1);
        }

        if (spinnerCategory.getSelectedItem().equals("Geography")) {
            selectCategory.setId(2);
        }

        if (spinnerCategory.getSelectedItem().equals("Maths")) {
            selectCategory.setId(3);
        }
        String difficulty = spinnerDifficulty.getSelectedItem().toString();

        //Get category ID from selectCategory object
        int categoryID = selectCategory.getId();

        //Get category name from selectCategory object
        String categoryName = selectCategory.getName();

        goToQuizPage(difficulty, categoryID, categoryName);

//        Intent intent = new Intent(this, GameActivity.class);
//        intent.putExtra(EXTRA_CATEGORY_ID, categoryID);
//        intent.putExtra(EXTRA_CATEGORY_NAME, categoryName);
//        intent.putExtra(EXTRA_DIFFICULTY, difficulty);
//        startActivityForResult(intent, REQUEST_CODE_QUIZ);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_QUIZ) {
            if (resultCode == RESULT_OK) {
                int score = data.getIntExtra(GameActivity.EXTRA_SCORE, 0);
                if (score > highscore) {
                    updateHighScore(score);
                }
            }
        }
    }

    private void loadCategories() {

        ArrayList<String> myList;
        myList = new ArrayList<>();

        final String categoriesHint = "Select category...";

        //Create instance of database
        QuizDbHelper dbHelper = QuizDbHelper.getInstance(this);


        //List of type categories
//        List<Category> categories = dbHelper.getAllCategories();

        //Convert List type of category categories to ArrayList type category categories
        ArrayList<Category> categories = new ArrayList<>(dbHelper.getAllCategories());

        //String [] ca
        String[] categoryStrings = new String[categories.size()];
        Category[] arr = categories.toArray(new Category[0]);

        for (int i = 0; i < categories.size(); i++) {
            categoryStrings[i] = arr[i].toString();
        }

        //Add hint to ArrayList of type String
        myList.add(categoriesHint);

        //Add both strings to ArrayList of type String
        Collections.addAll(myList, categoryStrings);


        ArrayAdapter<String> adapterCategories = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, myList);

        adapterCategories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapterCategories);
        spinnerCategory.getCount();

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (spinnerCategory.getSelectedItem().equals(categoriesHint)) {
                    //Do nothing
                } else {
                    Toast.makeText(MainActivity.this, spinnerCategory.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void loadDifficultyLevelsWithHint() {

        ArrayList<String> myList;
        myList = new ArrayList<>();

        String[] levels = Question.getAllDifficultyLevels();
        final String hint = "Select difficulty...";

        myList.add(hint);
        Collections.addAll(myList, levels);

        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, myList);

        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDifficulty.setAdapter(adapterDifficulty);
        spinnerDifficulty.getCount();

        spinnerDifficulty.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spinnerDifficulty.getSelectedItem().equals(hint)) {

                    //Do nothing

                } else {
                    Toast.makeText(MainActivity.this, spinnerDifficulty.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void loadHighScore() {
        SharedPreferences preferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        highscore = preferences.getInt(KEY_HIGHSCORE, 0);
        textViewHighScore.setText("Highscore: " + highscore);
    }

    private void updateHighScore(int newHighScore) {
        highscore = newHighScore;
        textViewHighScore.setText("Highscore: " + highscore);

        SharedPreferences preferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_HIGHSCORE, highscore);
        editor.apply();
    }

//    private void loadDifficultyLevels() {
//
//
//        String[] difficultyLevels = Question.getAllDifficultyLevels();
//        final String hint = "Select category...";
//
//
//        //Fill spinner with pre-defined difficulty levels
//        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<String>(this,
//                android.R.layout.simple_spinner_item, difficultyLevels);
////        adapterDifficulty.add(hint);
//        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinnerDifficulty.setAdapter(adapterDifficulty);
//
//
//    }


    public void startButton(View view) {
        if (spinnerDifficulty.getSelectedItem().equals("Select difficulty...")) {
            Toast.makeText(this, "Select a difficulty level to start", Toast.LENGTH_SHORT).show();
        } else if (spinnerCategory.getSelectedItem().equals("Select category...")) {
            Toast.makeText(this, "Select category to start", Toast.LENGTH_SHORT).show();
        } else {
            initializeQuiz();
        }

//        Intent intent = new Intent(this, GameActivity.class);
//        startActivity(intent);

    }


    private void goToQuizPage(String difficulty, int categoryID, String categoryName) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra(EXTRA_CATEGORY_ID, categoryID);
        intent.putExtra(EXTRA_CATEGORY_NAME, categoryName);
        intent.putExtra(EXTRA_DIFFICULTY, difficulty);
        startActivityForResult(intent, REQUEST_CODE_QUIZ);
    }


    public void optionsButton(View view) {
        optionsNextIntent();
    }

    private void optionsNextIntent() {
        Intent intent = new Intent(this, OptionsPage.class);
        startActivity(intent);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) {
            return;
        }

        // get the change of the x,y,z values of the accelerometer
        deltaX = Math.abs(lastX - event.values[0]);
        deltaY = Math.abs(lastY - event.values[1]);
        deltaZ = Math.abs(lastZ - event.values[2]);

        // if the change is below 2, it is set to zero
        if (deltaX < 2) {
            deltaX = 0;
        }
        if (deltaY < 2) {
            deltaY = 0;
        }
        // If gesture exceeds the threshold it calls the onShake method
        if (deltaX > vibrateThreshold || deltaY > vibrateThreshold || deltaZ > vibrateThreshold) {
            onShake();
        }

        lastX = event.values[0];
        lastY = event.values[1];
        lastZ = event.values[2];
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    //     Event listener for the gesture
    private void startShakeListener() {
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {

            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            vibrateThreshold = Math.min(15, accelerometer.getMaximumRange() / 2);
            System.out.println(vibrateThreshold);
        }
    }

    private void stopShakeListener() {
        sensorManager.unregisterListener(this);
    }

//     Borrowed from example at https://examples.javacodegeeks.com/android/core/hardware/sensor/android-accelerometer-example/


    private void onShake() {
        stopShakeListener();
        new AlertDialog.Builder(this).setMessage(R.string.instructions).setPositiveButton(R.string.okay_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startShakeListener();
            }
        }).show();
    }


    public void highScoresButton(View view) {
        goToHighScoresPage();
    }

    private void goToHighScoresPage() {
        Intent intent = new Intent(this, HighScoresPage.class);
        startActivity(intent);
    }
}





