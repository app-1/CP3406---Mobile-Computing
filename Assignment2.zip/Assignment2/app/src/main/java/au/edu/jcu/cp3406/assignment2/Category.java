package au.edu.jcu.cp3406.assignment2;

public class Category {
    //Create categories to populate category
    public static final int PROGRAMMING = 1;
    public static final int GEOGRAPHY = 2;
    public static final int MATH = 3;



    //Create objects associated with Category class
    private int id;
    private String name;

    //Recreate category
    public Category() {

    }

    public Category(String name) {
        this.name = name;
    }

    public static Object parseCategory(String value) {

        return null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return getName();
    }

    public static int valueOf(String category) {
        switch (category) {
            case "Programming": return PROGRAMMING;
            case "Geography": return GEOGRAPHY;
            case "Math": return MATH;
            case "Maths": return MATH;
            default: return 0;
        }
    }
}
