package au.edu.jcu.cp3406.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

public class AddQuestion extends AppCompatActivity {

    //Take in user inputs to add new questions
    // and categories to database

    //Create constants
    private EditText questionNumberInput;
    private EditText option1;
    private EditText option2;
    private EditText option3;
    private EditText correctAnswerOption;
    private Spinner addQuestionCategorySpinner;
    private Spinner addDifficultiesSpinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);

        questionNumberInput = findViewById(R.id.questionInput);
        addQuestionCategorySpinner = findViewById(R.id.spinnerCategory);
        addDifficultiesSpinner = findViewById(R.id.spinnerDifficulty);
        option1 = findViewById(R.id.answerOption1TextView);
        option2 = findViewById(R.id.answerOption2TextView);
        option3 = findViewById(R.id.answerOption3TextView);
        correctAnswerOption = findViewById(R.id.answerNumberInput);

//        //Prompt user for question
//        String userInputQuestion = questionNumberInput.getText().toString();
//
//        //Prompt user for answer options
//        String answerOption1 = option1.getText().toString();
//        String answerOption2 = option2.getText().toString();
//        String answerOption3 = option3.getText().toString();
//
//        //Prompt user to set correct answer
//        String userCorrectAnswerInput = correctAnswerOption.getText().toString();
//
//        //Convert user input for correct answer number into an int
//        Log.i("answer=", userCorrectAnswerInput);
////        int correctAnswerNumber = Integer.parseInt(userCorrectAnswerInput);
//        int correctAnswerNumber = 2;

        // Set/Load categories in spinner
        //Method call to load categories into spinner
        loadCategories();

        //Method call to load difficulty levels into spinner
        loadDifficulties();

        //User calls this to add a new question at one time
//        QuizDbHelper.getInstance(this).addQuestion(question);
    }


    public void submitQuestionButton(View view) {

        //check if input is empty
//        if(userInputQuestion.matches("")){
//            //Return toast
//            Toast.makeText(this, "Please enter valid number", Toast.LENGTH_SHORT).show();
//        }

//        editTextQuestionNumberInput = findViewById(R.id.questionInput);
        String userInputQuestion = questionNumberInput.getText().toString();

        //Prompt user for answer options
        String answerOption1 = option1.getText().toString();
        String answerOption2 = option2.getText().toString();
        String answerOption3 = option3.getText().toString();

        //Prompt user to set correct answer
        String correctAnswer = correctAnswerOption.getText().toString();

        //User selects difficulty

        //Check if text inputs are empty
        if (userInputQuestion.matches("") || answerOption1.matches("") || answerOption2.matches("")
                || answerOption3.matches("") || correctAnswer.matches("")) {
            Toast.makeText(this, "Input is empty. Please enter question", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Question successfully added", Toast.LENGTH_SHORT).show();

        }

        //Check if user inputs number for correct answer number input
        try {
            Integer.parseInt(correctAnswer);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input. Please enter a number", Toast.LENGTH_SHORT).show();
        }

        //Convert user input for correct answer number into an int
        int correctAnswerNumber = Integer.parseInt(correctAnswer);

        //Create question object
        Question question = new Question(userInputQuestion, answerOption1, answerOption2, answerOption3,
                correctAnswerNumber, addDifficultiesSpinner.getSelectedItem().toString(),
                Category.valueOf(addQuestionCategorySpinner.getSelectedItem().toString()));

        //Add question to data base
        QuizDbHelper.getInstance(this).addQuestion(question);

        //Submit button takes user back to landing page
        backToMainActivity();
    }

    //Populate spinner with categories
    private void loadCategories() {
        QuizDbHelper dbHelper = QuizDbHelper.getInstance(this);

        //Create list of category objects
        List<Category> categories = dbHelper.getAllCategories();

        ArrayAdapter<Category> adapterCategories = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);

        adapterCategories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addQuestionCategorySpinner.setAdapter(adapterCategories);
    }

    //Populate spinner with Difficulty levels
    private void loadDifficulties() {

        //Create list of difficult levels
        String[] difficulties = Question.getAllDifficultyLevels();

        ArrayAdapter<String> adapterDifficulties = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, difficulties);

        adapterDifficulties.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        addDifficultiesSpinner.setAdapter(adapterDifficulties);

    }

    //Method to take user back to main/landing screen when question is submitted
    private void backToMainActivity() {
        Intent back = new Intent(this, MainActivity.class);
        startActivity(back);
        finish();
    }


}
