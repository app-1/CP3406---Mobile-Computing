package au.edu.jcu.cp3406.assignment2;

public class Example {

    public enum Diff {
        EASY,
        MEDIUM,
        HARD
    }

    public static void main(String[] args) {
        Diff.valueOf("HARD");
    }
}
