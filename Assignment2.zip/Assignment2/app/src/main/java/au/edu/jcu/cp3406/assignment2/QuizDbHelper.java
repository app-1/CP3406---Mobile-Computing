package au.edu.jcu.cp3406.assignment2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import au.edu.jcu.cp3406.assignment2.QuizContract.*;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {
    //Create constants for SQL Database
    private static final String DATABASE_NAME = "QuizMe.db";
    private static final int DATABASE_VERSION = 1; //Database number set to two to account for user adding new column


    private static QuizDbHelper instance;

    private SQLiteDatabase db;

    public QuizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized QuizDbHelper getInstance(Context context) {
        if (instance == null) {
            instance = new QuizDbHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;

        final String SQL_CREATE_CATEGORIES_TABLE = "CREATE TABLE " +
                CategoriesTable.TABLE_NAME + "( " +
                CategoriesTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CategoriesTable.COLUMN_NAME + " TEXT " + ")";

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NUMBER + " INTEGER, " +
                QuestionsTable.COLUMN_DIFFICULTY + " TEXT, " +
                QuestionsTable.COLUMN_CATEGORY_ID + " INTEGER, " +
                "FOREIGN KEY(" + QuestionsTable.COLUMN_CATEGORY_ID + ") REFERENCES " +
                CategoriesTable.TABLE_NAME + "(" + CategoriesTable._ID + ")" + "ON DELETE CASCADE" +
                ")";

        final String SQL_CREATE_HIGH_SCORES_TABLE = "CREATE TABLE " +
                HighScoresTable.TABLE_NAME + " ( " +
                HighScoresTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                HighScoresTable.COLUMN_USER_NAME + " TEXT, " +
                HighScoresTable.COLUMN_HIGH_SCORES + " INTEGER )";

        db.execSQL(SQL_CREATE_CATEGORIES_TABLE);
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        db.execSQL(SQL_CREATE_HIGH_SCORES_TABLE);
        fillCategoriesTable();
        fillQuestionsTable();
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CategoriesTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + HighScoresTable.TABLE_NAME);
        onCreate(db);
    }

    //Called where database is opened
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    private void fillCategoriesTable() {
        Category c1 = new Category("Programming");
        insertCategory(c1);

        Category c2 = new Category("Geography");
        insertCategory(c2);

        Category c3 = new Category("Maths");
        insertCategory(c3);
    }


    //User calls this method to add one category
    public void addCategory(Category category) {

        //Assign database variable with writeable database;
        db = getWritableDatabase();
        insertCategory(category);
    }

    //User calls this method to add multiple categories
    public void addCategories(List<Category> categories) {
        db = getWritableDatabase();

        for (Category category : categories) {
            insertCategory(category);
        }
    }

    //User Update category
    public void updateCategory(Category category) {

        //Assign database to writeable database
        db = getWritableDatabase();

        //Create content values
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COLUMN_NAME, category.getName());
        db.update(CategoriesTable.COLUMN_NAME, cv, "name = ? ", new String[]{category.getName()});
    }

    public void deleteCategory(Category category) {
        db = getWritableDatabase();
        db.delete(CategoriesTable.COLUMN_NAME, "name = ? ", new String[]{category.getName()});

    }

    private void insertCategory(Category category) {
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COLUMN_NAME, category.getName());
        db.insert(CategoriesTable.TABLE_NAME, null, cv);
    }

    private void insertHighScore(String username, int scores) {
        ContentValues cv = new ContentValues();
        cv.put(HighScoresTable.COLUMN_USER_NAME, username);
        cv.put(HighScoresTable.COLUMN_HIGH_SCORES, scores);
        db.insert(HighScoresTable.TABLE_NAME, null, cv);
    }

    private void fillQuestionsTable() {

        Question q1 = new Question("Programming: How do you compare value of two strings?",
                ".equals()", "==", "=", 1, Question.DIFFICULTY_EASY,
                Category.PROGRAMMING);
        insertQuestion(q1);

        Question q2 = new Question("Geography: Which of these cities is not in Europe?",
                "Barcelona", "Moscow", "Reykjavik", 2, Question.DIFFICULTY_MEDIUM,
                Category.GEOGRAPHY);
        insertQuestion(q2);

        Question q3 = new Question("Math: Which of these is the correct quadratic formula?",
                "x = -b+-(sqrt((b^2-4*a*c)/2*a))", "x = -b+(sqrt((b^2+4*a*c)/2*a))", "a*x^3 + b - c", 3, Question.DIFFICULTY_HARD,
                Category.MATH);
        insertQuestion(q3);

        Question q4 = new Question("Math: Rowan orders 2 Zinger Stackers and 3 whopper juniors" +
                "He drops 1 and it gets covered in dirt. How many burgers will he eat for dinner? ",
                "4 burgers", "5 burgers", "4 burgers plus 1 high cholesterol", 1, Question.DIFFICULTY_EASY,
                Category.MATH);
        insertQuestion(q4);

        Question q5 = new Question("Maths: 2 + 2 - 1 = ?",
                "3", "4", "Quick Maths", 1, Question.DIFFICULTY_EASY,
                Category.MATH);
        insertQuestion(q5);

        Question q6 = new Question("Programming: How do you print a string in Java ?",
                "System.out.println('')", "System.print.log('')", "System.strike.playball('')", 1, Question.DIFFICULTY_EASY,
                Category.PROGRAMMING);
        insertQuestion(q6);

    }

    //Add question
    public void addQuestion(Question question) {
        //Assign database variable with writeable database;
        db = getWritableDatabase();
        insertQuestion(question);
    }

    //Add score to database
    public void addHighScore(String username, int score) {
        //Assign database variable with writeable database;
        db = getWritableDatabase();
        insertHighScore(username, score);
    }

    //Add list of questions
    public void addQuestion(List<Question> questions) {

        db = getWritableDatabase();

        for (Question question : questions) {
            insertQuestion(question);
        }
    }

    //Add questions along with variables to database
    private void insertQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_ANSWER_NUMBER, question.getAnswerNumber());
        cv.put(QuestionsTable.COLUMN_DIFFICULTY, question.getDifficulty());
        cv.put(QuestionsTable.COLUMN_CATEGORY_ID, question.getCategoryID());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<Category> getAllCategories() {
        List<Category> categoryList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + CategoriesTable.TABLE_NAME, null);

        //Recreate category as java objects from initial entries
        if (c.moveToFirst()) {
            do {
                Category category = new Category();
                category.setId(c.getInt(c.getColumnIndex(CategoriesTable._ID)));
                category.setName(c.getString(c.getColumnIndex(CategoriesTable.COLUMN_NAME)));
                categoryList.add(category);
            } while (c.moveToNext());
        }
        c.close();
        return categoryList;
    }

    //Retrieve questions from database, adding questions from questions table
    public ArrayList<Question> getAllQuestions() {

        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getColumnIndex(QuestionsTable._ID));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setAnswerNumber(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NUMBER)));
                question.setDifficulty(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_DIFFICULTY)));
                question.setCategoryID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY_ID)));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }

    //Retrieve questions from database based on difficulty level
    public ArrayList<Question> getQuestions(int categoryID, String difficulty) {

        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();

        String selection = QuestionsTable.COLUMN_CATEGORY_ID + " = ?" +
                " AND " + QuestionsTable.COLUMN_DIFFICULTY + " = ? ";
        String[] selectionArgs = new String[]{String.valueOf(categoryID), difficulty};

        Cursor c = db.query(
                QuestionsTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        //Create new string array which outputs difficulty String. Example, outputs Easy, Medium or Hard
//        String[] selectionArgs = new String[]{difficulty};
//        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME +
//                " WHERE " + QuestionsTable.COLUMN_DIFFICULTY + " = ?", selectionArgs);

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getColumnIndex(QuestionsTable._ID));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setAnswerNumber(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NUMBER)));
                question.setDifficulty(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_DIFFICULTY)));
                question.setCategoryID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY_ID)));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }
}
