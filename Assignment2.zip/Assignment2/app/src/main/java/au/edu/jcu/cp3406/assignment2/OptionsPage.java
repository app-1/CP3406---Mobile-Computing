package au.edu.jcu.cp3406.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class OptionsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options_page);
    }

    public void addQuestion(View view) {
        nextIntent();
    }

    private void nextIntent() {
        Intent intent = new Intent(this, AddQuestion.class);
        startActivity(intent);

    }
}
