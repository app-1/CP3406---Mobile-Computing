package au.edu.jcu.cp3406.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import static au.edu.jcu.cp3406.assignment2.MainActivity.KEY_HIGHSCORE;
import static au.edu.jcu.cp3406.assignment2.MainActivity.SHARED_PREFS;

public class HighScoresPage extends AppCompatActivity {

    //define variables
    private EditText nameUserInput;
    private TextView nameHighScoreDisplay;

    private TextView scoreView;

    private int highscore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_scores);

        //find ID's
        nameUserInput = findViewById(R.id.nameUserInput);
        nameHighScoreDisplay = findViewById(R.id.nameHighSCView);
        scoreView = findViewById(R.id.scoreTextView);

//        displayUserName();
        loadHighScore();
    }

    public void backButton(View view) {
        finish();
    }

//    private void displayUserName(){
//        String name = nameUserInput.getText().toString();
//
//        if(name.length() > 0){
//            //Create new database object
//            QuizDbHelper dbHelper = new QuizDbHelper(this);
//            //Add username and score to database
//            dbHelper.addHighScore(name, highscore);
//        }
//
//        nameHighScoreDisplay.setText(name);
//
//    }


    private void loadHighScore() {
        SharedPreferences preferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        highscore = preferences.getInt(KEY_HIGHSCORE, 0);
        scoreView.setText("Highscore: " + highscore);
    }


    private void updateHighScore(int highscoreNew) {
        highscore = highscoreNew;
        scoreView.setText("Highscore: " + highscore);

        SharedPreferences preferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_HIGHSCORE, highscore);
        editor.apply();
    }

}
