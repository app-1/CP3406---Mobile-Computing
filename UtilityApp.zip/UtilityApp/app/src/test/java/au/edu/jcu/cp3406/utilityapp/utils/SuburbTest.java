package au.edu.jcu.cp3406.utilityapp.utils;

import org.junit.Test;

import static org.junit.Assert.*;

public class SuburbTest {

    private Suburb suburb = new Suburb("Jensen");
    @Test
    public void getName() {
        assertEquals("Jensen",suburb.getName());
    }

    @Test
    public void setName() {
        Suburb suburb = new Suburb("Burdell");
        assertEquals("Burdell", suburb.getName());
    }
}