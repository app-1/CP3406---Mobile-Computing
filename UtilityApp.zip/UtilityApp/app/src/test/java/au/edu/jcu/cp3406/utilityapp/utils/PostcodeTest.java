package au.edu.jcu.cp3406.utilityapp.utils;

import org.junit.Test;

import static org.junit.Assert.*;

public class PostcodeTest {

    private Postcode postcode = new Postcode(4818);

    @Test
    public void getPostcode() {
        assertEquals(4818, postcode.getPostcode());
    }

    @Test
    public void setPostcode() {
        postcode.setPostcode(4814);
        assertEquals(4814, postcode.getPostcode());
    }
}