package au.edu.jcu.cp3406.utilityapp.utils;

import org.junit.Test;

import static org.junit.Assert.*;

public class RestaurantOptionsTest {

    private RestaurantOptions restaurant = new RestaurantOptions("Noodle Box Woodlands");

    @Test
    public void getName() {
        assertEquals("Noodle Box Woodlands", restaurant.getName());
    }

    @Test
    public void setName() {
        RestaurantOptions restaurant = new RestaurantOptions("Bushy Beach Tavern");
        assertEquals("Bushy Beach Tavern", restaurant.getName());
    }
}