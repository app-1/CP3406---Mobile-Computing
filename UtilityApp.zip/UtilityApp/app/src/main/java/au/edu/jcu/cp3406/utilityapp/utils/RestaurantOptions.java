package au.edu.jcu.cp3406.utilityapp.utils;

public class RestaurantOptions {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RestaurantOptions(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
