package au.edu.jcu.cp3406.utilityapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;

public class ContactDelivery extends AppCompatActivity {

    //Create instances of text fields
    EditText name, email, phoneNumber;

    //Create instance of button
    Button nextButtonContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_delivery);

        nextButtonContact = findViewById(R.id.nextButton);

        //Find ID's of textField instances
        name = findViewById(R.id.nameEditText);
        email = findViewById(R.id.emailEditText);
        phoneNumber = findViewById(R.id.phoneNumberEditText);

        //Active checking of textFields
        name.addTextChangedListener(contactTextWatcher);
        email.addTextChangedListener(contactTextWatcher);
        phoneNumber.addTextChangedListener(contactTextWatcher);

        //

        String previousButton = getIntent().getStringExtra("previousButton");
        if (previousButton!= null && previousButton.equals("delivery")) {
            EditText deliveryText = findViewById(R.id.deliveryAddressEdit);
            deliveryText.setVisibility(View.VISIBLE);

            ConstraintLayout layout = findViewById(R.id.contactDeliveryConstraint);
            ConstraintSet constraint = new ConstraintSet();
            constraint.clone(layout);
            constraint.connect(R.id.deliveryAddressEdit, ConstraintSet.TOP, R.id.phoneNumberEditText, ConstraintSet.BOTTOM);
            constraint.applyTo(layout);
        }
    }

    public void nextIntent(View view) {
        Intent intent = new Intent(this, OrderComplete.class);

        if (getIntent().getExtras() != null) {
            intent.putExtras(getIntent().getExtras());
        }

        intent.putExtra("Name", name.getText().toString());
        intent.putExtra("Email", email.getText().toString());
        intent.putExtra("Phone", phoneNumber.getText().toString());
        EditText deliveryText = findViewById(R.id.deliveryAddressEdit);
        intent.putExtra("Address", deliveryText.getText().toString());

        startActivity(intent);
    }

    public void backIntent(View view) {
        Intent intent = new Intent(this, PickUpOrDelivery.class);
        startActivity(intent);
    }

    private boolean checkEmptyTextField() {

        String emailInput = email.getText().toString().trim();

        if (name.length() == 0) {
            name.setError("Enter name");
            String nameError = "Field blank. Enter a name!";
            Toast.makeText(ContactDelivery.this, nameError, Toast.LENGTH_LONG).show();
            return false;
        }

        if (email.length() == 0 || !emailInput.contains("@")) {
            email.setError("Enter email with @ symbol");
            String passwordError = "Field blank. Enter a valid password containing @ symbol";
            Toast.makeText(ContactDelivery.this, passwordError, Toast.LENGTH_SHORT).show();
            return false;
        }

        if (phoneNumber.length() == 0) {
            phoneNumber.setError("Enter phone number");
            String phoneNumberError = "Field blank. Enter phone number!";
            Toast.makeText(ContactDelivery.this, phoneNumberError, Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private TextWatcher contactTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            nextButtonContact.setEnabled(checkEmptyTextField());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };
}
