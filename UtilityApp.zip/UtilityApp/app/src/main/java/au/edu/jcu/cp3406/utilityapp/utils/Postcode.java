package au.edu.jcu.cp3406.utilityapp.utils;

public class Postcode {
    private int postcode;

    public int getPostcode() {
        return postcode;
    }

    public void setPostcode(int postcode) {
        this.postcode = postcode;
    }

    public Postcode(int postcode) {
        this.postcode = postcode;
    }

    @Override
    public String toString() {
        return String.valueOf(postcode);
    }
}
