package au.edu.jcu.cp3406.utilityapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import au.edu.jcu.cp3406.utilityapp.utils.Postcode;
import au.edu.jcu.cp3406.utilityapp.utils.RestaurantOptions;
import au.edu.jcu.cp3406.utilityapp.utils.Suburb;

public class AreaSelect extends AppCompatActivity {

    private Spinner suburbSpinner;
    private Spinner postCodeSpinner;
    private Spinner restaurantSpinner;

    public Button nextButton;

    public void init(){
        nextButton = findViewById(R.id.nextButton);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AreaSelect.this, PickUpOrDelivery.class);

                Postcode code = (Postcode) postCodeSpinner.getSelectedItem();
                RestaurantOptions restaurant = (RestaurantOptions) restaurantSpinner.getSelectedItem();
                Suburb suburb = (Suburb) suburbSpinner.getSelectedItem();

                intent.putExtra("Postcode", code.getPostcode());
                intent.putExtra("Restaurant", restaurant.getName());
                intent.putExtra("Suburb", suburb.getName());

                startActivity(intent);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_select);
        init();

        suburbSpinner = findViewById(R.id.suburbSpinner);
        postCodeSpinner = findViewById(R.id.postCodeSpinner);
        restaurantSpinner = findViewById(R.id.restaurantSpinner);

        //List of suburbs
        List<Suburb> suburbList = new ArrayList<>();
        Suburb no1 = new Suburb("Beach Holm");
        suburbList.add(no1);
        Suburb no2 = new Suburb("Black River");
        suburbList.add(no2);
        Suburb no3 = new Suburb("Blue Hills");
        suburbList.add(no3);
        Suburb no4 = new Suburb("Bluewater");
        suburbList.add(no4);
        Suburb no5 = new Suburb("Bluewater Park");
        suburbList.add(no5);
        Suburb no6 = new Suburb("Bohle");
        suburbList.add(no6);
        Suburb no7 = new Suburb("Burdell");
        suburbList.add(no7);
        Suburb no8 = new Suburb("Bushland Beach");
        suburbList.add(no8);
        Suburb no9 = new Suburb("Cosgrove");
        suburbList.add(no9);
        Suburb no10 = new Suburb("Deeragun");
        suburbList.add(no10);
        Suburb no11 = new Suburb("Jensen");
        suburbList.add(no11);
        Suburb no12 = new Suburb("Mount Low");
        suburbList.add(no12);
        Suburb no13 = new Suburb("Mount St John");
        suburbList.add(no13);
        Suburb no14 = new Suburb("Saunders Beach");
        suburbList.add(no14);
        Suburb no15 = new Suburb("Shaw");
        suburbList.add(no15);
        Suburb no16 = new Suburb("Thornton");
        suburbList.add(no16);
        Suburb no17 = new Suburb("Toolakea");
        suburbList.add(no17);
        Suburb no18 = new Suburb("Yabulu");
        suburbList.add(no18);

        //List of postcodes
        List<Postcode> postcodeList = new ArrayList<>();
        Postcode code1 = new Postcode(4818);
        postcodeList.add(code1);

        //List of Restaurants
        List<RestaurantOptions> restaurantOptions = new ArrayList<>();
        RestaurantOptions saundersBarBistro = new RestaurantOptions("Saunders Beach Bar & Bistro");
        restaurantOptions.add(saundersBarBistro);
        RestaurantOptions saundersBistroPizza= new RestaurantOptions("Saunders Beach Bistro & Pizza");
        restaurantOptions.add(saundersBistroPizza);
        RestaurantOptions dominosBushlandBeach = new RestaurantOptions("Dominos Bushland Beach");
        restaurantOptions.add(dominosBushlandBeach);
        RestaurantOptions bushlandBeachTavern = new RestaurantOptions("Bushland Beach Tavern");
        restaurantOptions.add(bushlandBeachTavern);
        RestaurantOptions greatJewel = new RestaurantOptions("Great Jewel of India Deeragun");
        restaurantOptions.add(greatJewel);
        RestaurantOptions nanKing = new RestaurantOptions("Nanking Woodlands");
        restaurantOptions.add(nanKing);


        ArrayAdapter<Suburb> suburbAdapter = new ArrayAdapter<Suburb>(this, android.R.layout.simple_spinner_item, suburbList);
        ArrayAdapter<Postcode> postCodeAdapter = new ArrayAdapter<Postcode>(this, android.R.layout.simple_spinner_item, postcodeList);
        ArrayAdapter<RestaurantOptions> restaurantAdapter = new ArrayAdapter<RestaurantOptions>(this, android.R.layout.simple_spinner_item, restaurantOptions);

        suburbAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        postCodeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        restaurantAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        suburbSpinner.setAdapter(suburbAdapter);
        postCodeSpinner.setAdapter(postCodeAdapter);
        restaurantSpinner.setAdapter(restaurantAdapter);

        suburbSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Suburb suburb = (Suburb) parent.getSelectedItem();
                displaySuburbData(suburb);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        postCodeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Postcode code = (Postcode) parent.getSelectedItem();
                displayPostCodeData(code);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        restaurantSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                RestaurantOptions restaurant = (RestaurantOptions) parent.getSelectedItem();
                displayRestaurantData(restaurant);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void getSelectedSuburb(View view) {
        Suburb suburb = (Suburb) suburbSpinner.getSelectedItem();
        displaySuburbData(suburb);
    }

    private void displaySuburbData(Suburb suburb) {
        String name = suburb.getName();

        String suburbData = "Name: " + name;
        Toast.makeText(this, suburbData, Toast.LENGTH_SHORT).show();
    }

    public void getSelectedPostCode(View view) {
        Postcode code = (Postcode) postCodeSpinner.getSelectedItem();
        displayPostCodeData(code);
    }

    private void displayPostCodeData(Postcode code) {
        String postCodeData = "Postcode: " + code;
        Toast.makeText(this, postCodeData, Toast.LENGTH_SHORT).show();
    }

    public void getSelectedRestaurant(View view) {
        RestaurantOptions restaurant = (RestaurantOptions) restaurantSpinner.getSelectedItem();
        displayRestaurantData(restaurant);
    }

    private void displayRestaurantData(RestaurantOptions restaurant) {
        String restaurantData = "Restaurant: " + restaurant;
        Toast.makeText(this, restaurantData, Toast.LENGTH_SHORT).show();
    }
}
