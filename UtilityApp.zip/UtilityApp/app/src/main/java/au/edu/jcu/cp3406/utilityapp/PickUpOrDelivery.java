package au.edu.jcu.cp3406.utilityapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class PickUpOrDelivery extends AppCompatActivity {

    //Create textViews
    EditText deliveryText;

    public void pickupButton(View view) {
        Intent intent = new Intent(this, ContactDelivery.class);
        intent.putExtra("previousButton", "pickup");
        startActivity(intent);
    }

    public void deliveryButton(View view) {
        Intent intent = new Intent(this, ContactDelivery.class);
        intent.putExtra("previousButton", "delivery");
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_up_or_delivery);
        deliveryText = findViewById(R.id.deliveryAddressEdit);
    }

}
