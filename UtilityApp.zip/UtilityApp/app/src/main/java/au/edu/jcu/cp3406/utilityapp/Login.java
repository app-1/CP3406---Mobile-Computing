package au.edu.jcu.cp3406.utilityapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {


    //Create instance of textfields
    EditText name, email, password;

    //Instance of button
    Button enterButton;

    //Initialisation class for button. Error checking of text fields also take place within the class
    public void init() {
        //define button
        enterButton = findViewById(R.id.enterButton);

        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeIntent();
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();

        //define text input fields
        name = findViewById(R.id.nameEditText);
        email = findViewById(R.id.emailEditText);
        password = findViewById(R.id.passwordEditText);

        //Active checking of textfields
        name.addTextChangedListener(loginTextWatcher);
        email.addTextChangedListener(loginTextWatcher);
        password.addTextChangedListener(loginTextWatcher);


    }

    private void changeIntent() {
        Intent intent = new Intent(Login.this, AreaSelect.class);
        startActivity(intent);
    }


    private boolean checkEmptyTextFields() {

        String nameInput = name.getText().toString().trim();
        String emailInput = email.getText().toString().trim();
        String passwordInput = password.getText().toString().trim();

        if (nameInput.length() == 0) {
            name.setError("Enter name");
            String nameError = "Field blank. Enter a name!";
            Toast.makeText(Login.this, nameError, Toast.LENGTH_LONG).show();
            return false;
        }

        if (emailInput.length() == 0 || !emailInput.contains("@")) {
            email.setError("Enter email with @ symbol");
            String emailError = "Field blank. Enter a valid password!";
            Toast.makeText(Login.this, emailError, Toast.LENGTH_SHORT).show();
            return false;

        }


        if (passwordInput.length() == 0) {
            password.setError("Enter password");
            String passwordError = "Field blank. Enter a valid password!";
            Toast.makeText(Login.this, passwordError, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }


    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            //
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

//            String nameInput = name.getText().toString().trim();
//            String emailInput = email.getText().toString().trim();
//            String passwordInput = password.getText().toString().trim();

            enterButton.setEnabled(checkEmptyTextFields());
        }

        @Override
        public void afterTextChanged(Editable s) {
            //
        }
    };

}
