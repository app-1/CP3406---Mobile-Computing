package au.edu.jcu.cp3406.utilityapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class OrderComplete extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_complete);

        LinearLayout layout = findViewById(R.id.informationOrderTable);

        TextView orderSuccess = findViewById(R.id.orderCompleteLabel);
        Random random = new Random();
        orderSuccess.setText("Order #" + random.nextInt((50000 - 100) + 1) + " Successful");

//        Intent intent = getIntent();
//        TextView postCodeText = new TextView(this);
//        int postCode = intent.getIntExtra("Postcode", 0);
//        postCodeText.setGravity(Gravity.CENTER);
//        postCodeText.setText(postCode);
//        layout.addView(postCodeText);

//        sendInfo("Restaurant", layout);
//        sendInfo("Suburb", layout);
        sendInfo("Name", layout);
        sendInfo("Email", layout);
        sendInfo("Phone", layout);
        sendInfo("Address", layout);

    }

    private void sendInfo(String info, LinearLayout layout) {
        Intent intent = getIntent();
        TextView infoText = new TextView(this);
        String phone = intent.getStringExtra(info);
        infoText.setGravity(Gravity.CENTER);
        infoText.setText(phone);
        layout.addView(infoText);
    }

    public void orderAgainButton(View view) {
        Intent intent = new Intent(this, AreaSelect.class);
        startActivity(intent);
        finish();
    }

    public void closeButton(View view) {
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
        finish();
    }


}
