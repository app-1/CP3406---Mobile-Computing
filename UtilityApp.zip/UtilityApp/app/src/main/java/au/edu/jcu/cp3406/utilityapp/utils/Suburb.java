package au.edu.jcu.cp3406.utilityapp.utils;

public class Suburb {

    private String name;

    public Suburb(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public String toString() {
        return name;
    }
}
